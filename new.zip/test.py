from pyrogram import Client

api_id =  23446862
api_hash = '665d96308e3b3e4ae0cd704e1671823a'
app = Client('sessions/aeoenzbxsx', api_id=api_id, api_hash=api_hash)
app.connect()

app.send_message('@lL7Nl', 'hello')

app.disconnect()